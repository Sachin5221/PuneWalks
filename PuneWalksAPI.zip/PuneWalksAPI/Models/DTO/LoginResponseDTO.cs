﻿namespace PuneWalksAPI.Models.DTO
{
    public class LoginResponseDTO
    {
        public string JwtToken { get; set; }
    }
}
