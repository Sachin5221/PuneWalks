﻿namespace PuneWalksAPI.Models.DTO
{
    public class DifficultyDTO
    {
        public Guid Id { get; set; }
        public string Name { get; set; } 
    }
}
